/*/*******************************************************************************
**                                                                            **
**                     Jiedi(China nanjing)Ltd.                               **
**	               创建：丁宋涛 夏曹俊，此代码可用作为学习参考                **
*******************************************************************************/

/*****************************FILE INFOMATION***********************************
**
** Project       : Linux程序设计从入门到实战
** Contact       : xiacaojun@qq.com
**  博客   : http://blog.csdn.net/jiedichina
**	视频课程 : 网易云课堂	http://study.163.com/u/xiacaojun		
			   腾讯课堂		https://jiedi.ke.qq.com/				
			   csdn学院		http://edu.csdn.net/lecturer/lecturer_detail?lecturer_id=961	
**             51cto学院	http://edu.51cto.com/lecturer/index/user_id-12016059.html	
** 			   老夏课堂		http://www.laoxiaketang.com 
**                 
**   Linux程序设计从入门到实战课程 课程群 ：1026542536 加入群下载代码和交流
**   微信公众号  : jiedi2007
**		头条号	 : 夏曹俊
**
*****************************************************************************
//！！！！！！！！！ Linux程序设计从入门到实战 课程  QQ群：1026542536下载代码和交流*/
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>

#define MAXARGS	20
#define ARGLEN	100

int execute(char * arglist[]);
char* makestring(char * buf);
int main(){
	char *arglist[MAXARGS+1];//构造命令行参数
	int numargs;//逐个解析命令
	char argbuf[ARGLEN];
	numargs = 0;
	while(numargs<MAXARGS){
		printf("Arg[%d]?",numargs);
		if(fgets(argbuf,ARGLEN,stdin) && *argbuf!='\n')
			arglist[numargs++]=makestring(argbuf);
		else{
			if(numargs>0){
				arglist[numargs] = NULL;
				execute(arglist);
				numargs = 0;
			}
		}
	}
	return 0;
}


int execute(char * arglist[]){
	execvp(arglist[0],arglist);
	perror("execvp failed");
	exit(1);
}

char* makestring(char * buf){
	char* cp;
	buf[strlen(buf)-1] = '\0';
	cp =(char*) malloc(strlen(buf)+1);
	if(cp == NULL){
		fprintf(stderr,"no memory \n");
		exit(1);
	}
	strcpy(cp,buf);
	return cp;
}
