/*/*******************************************************************************
**                                                                            **
**                     Jiedi(China nanjing)Ltd.                               **
**	               创建：丁宋涛 夏曹俊，此代码可用作为学习参考                **
*******************************************************************************/

/*****************************FILE INFOMATION***********************************
**
** Project       : Linux程序设计从入门到实战
** Contact       : xiacaojun@qq.com
**  博客   : http://blog.csdn.net/jiedichina
**	视频课程 : 网易云课堂	http://study.163.com/u/xiacaojun		
			   腾讯课堂		https://jiedi.ke.qq.com/				
			   csdn学院		http://edu.csdn.net/lecturer/lecturer_detail?lecturer_id=961	
**             51cto学院	http://edu.51cto.com/lecturer/index/user_id-12016059.html	
** 			   老夏课堂		http://www.laoxiaketang.com 
**                 
**   Linux程序设计从入门到实战课程 课程群 ：1026542536 加入群下载代码和交流
**   微信公众号  : jiedi2007
**		头条号	 : 夏曹俊
**
*****************************************************************************
//！！！！！！！！！ Linux程序设计从入门到实战 课程  QQ群：1026542536下载代码和交流*/
//关闭规范输入，使得程序可以在用户敲键的时候直接得到输入的字符
#include <stdio.h>
#include <stdlib.h>
#include <termios.h>

#define QUESTION "跟着老夏学开发"

int get_response(char * question);
void set_crmode();
void tty_mode();
int main(void){
	int response;
	tty_mode(0);//保存tty的模式
	set_crmode();//将tty设置成一个字符接着一个字符的模式
	response = get_response(QUESTION);
	tty_mode(1);
	return 0;
}
int get_response(char * question){
	int input;
	printf("%s (q: for quit the program)",question);
	while(1){
		switch(input = getchar()){
			case 'q':
			case 'Q': return 0;
			case EOF:return 1;
			default:
			printf("升值加薪都找他 %c\n",input);
		}
	
	}

}

void set_crmode(){
	struct termios ttystate;
	tcgetattr(0,&ttystate);
	ttystate.c_lflag &= ~ICANON;//关闭规范模式
	ttystate.c_cc[VMIN] = 1;//编程实现一个一个读字符的需求
	tcsetattr(0,TCSANOW,&ttystate);
	
}

void tty_mode(int how){
	static struct termios original_mode;
	if(how == 0)
		tcgetattr(0,&original_mode);
	else
	{
		tcsetattr(0,TCSANOW,&original_mode);
		return ;
	}
}