/*/*******************************************************************************
**                                                                            **
**                     Jiedi(China nanjing)Ltd.                               **
**	               创建：丁宋涛 夏曹俊，此代码可用作为学习参考                **
*******************************************************************************/

/*****************************FILE INFOMATION***********************************
**
** Project       : Linux程序设计从入门到实战
** Contact       : xiacaojun@qq.com
**  博客   : http://blog.csdn.net/jiedichina
**	视频课程 : 网易云课堂	http://study.163.com/u/xiacaojun		
			   腾讯课堂		https://jiedi.ke.qq.com/				
			   csdn学院		http://edu.csdn.net/lecturer/lecturer_detail?lecturer_id=961	
**             51cto学院	http://edu.51cto.com/lecturer/index/user_id-12016059.html	
** 			   老夏课堂		http://www.laoxiaketang.com 
**                 
**   Linux程序设计从入门到实战课程 课程群 ：1026542536 加入群下载代码和交流
**   微信公众号  : jiedi2007
**		头条号	 : 夏曹俊
**
*****************************************************************************
//！！！！！！！！！ Linux程序设计从入门到实战 课程  QQ群：1026542536下载代码和交流*/
#include "myWrapper.h"

void* thread_function(void* argv);
sem_t bin_sem;

#define WORK_AREA 1024
char work_area[WORK_AREA];

int main(){
	int res;
	pthread_t a_thread;
	void* thread_result;
	res = sem_init(&bin_sem,0,0);
	res = pthread_create(&a_thread,NULL,thread_function,NULL);
	printf("input some words,press (end) to finished\n");
	while(strncmp("end",work_area,3)!=0){
		 fgets(work_area,WORK_AREA,stdin);
		 sem_post(&bin_sem);
		
	}
	printf("finished Main Thread\n");
	sem_destroy(&bin_sem);
	exit(0);
}

void* thread_function(void* argv){
	sem_wait(&bin_sem);
	while(strncmp("end",work_area,3)!=0){
		 printf("You have input %d characters\n",strlen(work_area));
		 sem_wait(&bin_sem);
		
	}
	pthread_exit(NULL);
}