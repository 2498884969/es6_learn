/*/*******************************************************************************
**                                                                            **
**                     Jiedi(China nanjing)Ltd.                               **
**	               创建：丁宋涛 夏曹俊，此代码可用作为学习参考                **
*******************************************************************************/

/*****************************FILE INFOMATION***********************************
**
** Project       : Linux程序设计从入门到实战
** Contact       : xiacaojun@qq.com
**  博客   : http://blog.csdn.net/jiedichina
**	视频课程 : 网易云课堂	http://study.163.com/u/xiacaojun		
			   腾讯课堂		https://jiedi.ke.qq.com/				
			   csdn学院		http://edu.csdn.net/lecturer/lecturer_detail?lecturer_id=961	
**             51cto学院	http://edu.51cto.com/lecturer/index/user_id-12016059.html	
** 			   老夏课堂		http://www.laoxiaketang.com 
**                 
**   Linux程序设计从入门到实战课程 课程群 ：1026542536 加入群下载代码和交流
**   微信公众号  : jiedi2007
**		头条号	 : 夏曹俊
**
*****************************************************************************
//！！！！！！！！！ Linux程序设计从入门到实战 课程  QQ群：1026542536下载代码和交流*/
#define _GNU_SOURCE
#include "myWrapper.h"
#include <sys/syscall.h>
#define NR_THREAD 1
#define ERRBUF_LEN 4096

void* thread_work(void* param){
	int TID = syscall(SYS_gettid);
	printf("thread:%d IN\n",TID);
	printf("thread:%d pthread_self return %p\n",TID,(void*)pthread_self());
	sleep(60);
	printf("thread:%d Finished\n",TID);
	return NULL;
	
}

int main(int argc,char* argv[]){
	pthread_t tid[NR_THREAD];
	pthread_t tid_2[NR_THREAD];
	char errbuf[ERRBUF_LEN];
	int i,ret;
	for(i=0;i<NR_THREAD;i++){
		ret = pthread_create(&tid[i],NULL,thread_work,NULL);
	}
	
	#ifdef NO_JOIN
		sleep(100);
	#else
		printf("join thread begin\n");
		for(i=0;i<NR_THREAD;i++){
			pthread_join(tid[i],NULL);
			
		}
	#endif
		for(i=0;i<NR_THREAD;i++){
			ret = pthread_create(&tid[i],NULL,thread_work,NULL);
			
		}
		sleep(1000);
	exit(0);
}