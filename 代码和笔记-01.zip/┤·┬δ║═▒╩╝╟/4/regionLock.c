/*/*******************************************************************************
**                                                                            **
**                     Jiedi(China nanjing)Ltd.                               **
**	               创建：丁宋涛 夏曹俊，此代码可用作为学习参考                **
*******************************************************************************/

/*****************************FILE INFOMATION***********************************
**
** Project       : Linux程序设计从入门到实战
** Contact       : xiacaojun@qq.com
**  博客   : http://blog.csdn.net/jiedichina
**	视频课程 : 网易云课堂	http://study.163.com/u/xiacaojun		
			   腾讯课堂		https://jiedi.ke.qq.com/				
			   csdn学院		http://edu.csdn.net/lecturer/lecturer_detail?lecturer_id=961	
**             51cto学院	http://edu.51cto.com/lecturer/index/user_id-12016059.html	
** 			   老夏课堂		http://www.laoxiaketang.com 
**                 
**   Linux程序设计从入门到实战课程 课程群 ：1026542536 加入群下载代码和交流
**   微信公众号  : jiedi2007
**		头条号	 : 夏曹俊
**
*****************************************************************************
//！！！！！！！！！ Linux程序设计从入门到实战 课程  QQ群：1026542536下载代码和交流*/
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

const char* testfile = "/tmp/dingst_test";

int main(){
	int file_desc;
	int byte_count;
	char* byte_to_write = "A";
	struct flock region_1;
	struct flock region_2;
	int res;
	
	file_desc = open(testfile,O_RDWR| O_CREAT,0666);
	if(!file_desc){
		fprintf(stderr,"unable to open %s",testfile);
		exit(1);
	}
	
	for(byte_count=0;byte_count < 100; byte_count++){
		write(file_desc,byte_to_write,1);
	}
	
	//给区域1加一个共享锁
	region_1.l_type = F_RDLCK;
	region_1.l_whence = SEEK_SET;
	region_1.l_start = 10;
	region_1.l_len = 20;
	
	//40-50加独占锁
	region_2.l_type = F_WRLCK;
	region_2.l_whence = SEEK_SET;
	region_2.l_start = 40;
	region_2.l_len = 10;
	
	printf("process %d locking file\n",getpid());
	res = fcntl(file_desc,F_SETLK,&region_1);
	if(res == -1)
		fprintf(stderr,"fail to lock region 1\n");
	res = fcntl(file_desc,F_SETLK,&region_2);
	if(res == -1)
		fprintf(stderr,"fail to lock region 2\n");
	
	sleep(60);
	printf("process %d closing file\n",getpid());
	close(file_desc);
	exit(0);
	
}