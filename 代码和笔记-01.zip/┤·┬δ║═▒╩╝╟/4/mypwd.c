/*/*******************************************************************************
**                                                                            **
**                     Jiedi(China nanjing)Ltd.                               **
**	               创建：丁宋涛 夏曹俊，此代码可用作为学习参考                **
*******************************************************************************/

/*****************************FILE INFOMATION***********************************
**
** Project       : Linux程序设计从入门到实战
** Contact       : xiacaojun@qq.com
**  博客   : http://blog.csdn.net/jiedichina
**	视频课程 : 网易云课堂	http://study.163.com/u/xiacaojun		
			   腾讯课堂		https://jiedi.ke.qq.com/				
			   csdn学院		http://edu.csdn.net/lecturer/lecturer_detail?lecturer_id=961	
**             51cto学院	http://edu.51cto.com/lecturer/index/user_id-12016059.html	
** 			   老夏课堂		http://www.laoxiaketang.com 
**                 
**   Linux程序设计从入门到实战课程 课程群 ：1026542536 加入群下载代码和交流
**   微信公众号  : jiedi2007
**		头条号	 : 夏曹俊
**
*****************************************************************************
//！！！！！！！！！ Linux程序设计从入门到实战 课程  QQ群：1026542536下载代码和交流*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>

ino_t get_indoe(char*);
void printpathto(ino_t);
void inum_to_name(ino_t,char*,int);

int main(void){
	printpathto(get_indoe("."));
	putchar('\n');
	return 0;
}

//递归调用直到信息显示
void printpathto(ino_t this_inode){
	ino_t my_inode;
	char its_name[BUFSIZ];
	if(get_indoe("..") != this_inode){
		chdir("..");
		inum_to_name(this_inode,its_name,BUFSIZ);
		my_inode = get_indoe(".");
		printpathto(my_inode);
		printf("/%s",its_name);
	}
}

void inum_to_name(ino_t inode_to_find,char* namebuf,int buflen){
	DIR *dir_ptr;
	struct dirent* direntp;
	dir_ptr = opendir(".");
	if(dir_ptr == NULL){
		perror(".");
		exit(1);
	}
	
	while((direntp = readdir(dir_ptr))!=NULL){
		if(direntp->d_ino == inode_to_find){
			strncpy(namebuf,direntp->d_name,buflen);
			namebuf[buflen-1]='\0';
			closedir(dir_ptr);
			return;
		
		}
	
	}
	
	fprintf(stderr,"error to find inum %d\n",inode_to_find);
	exit(1);
}
ino_t get_indoe(char *fname){
	struct stat info;
	if(stat(fname,&info) == -1){
		fprintf(stderr,"Cannot stat");
		perror(fname);
		exit(1);
	}
	return info.st_ino;
}

