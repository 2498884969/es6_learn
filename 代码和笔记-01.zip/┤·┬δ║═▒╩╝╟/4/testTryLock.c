/*/*******************************************************************************
**                                                                            **
**                     Jiedi(China nanjing)Ltd.                               **
**	               创建：丁宋涛 夏曹俊，此代码可用作为学习参考                **
*******************************************************************************/

/*****************************FILE INFOMATION***********************************
**
** Project       : Linux程序设计从入门到实战
** Contact       : xiacaojun@qq.com
**  博客   : http://blog.csdn.net/jiedichina
**	视频课程 : 网易云课堂	http://study.163.com/u/xiacaojun		
			   腾讯课堂		https://jiedi.ke.qq.com/				
			   csdn学院		http://edu.csdn.net/lecturer/lecturer_detail?lecturer_id=961	
**             51cto学院	http://edu.51cto.com/lecturer/index/user_id-12016059.html	
** 			   老夏课堂		http://www.laoxiaketang.com 
**                 
**   Linux程序设计从入门到实战课程 课程群 ：1026542536 加入群下载代码和交流
**   微信公众号  : jiedi2007
**		头条号	 : 夏曹俊
**
*****************************************************************************
//！！！！！！！！！ Linux程序设计从入门到实战 课程  QQ群：1026542536下载代码和交流*/
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

const char* testfile = "/tmp/dingst_test";
#define SIZE_TO_TRY 5

void show_lock_info(struct flock* to_show);

int main(){
	int file_desc;
	int res;
	struct flock region_to_test;
	int start_byte;
	
	file_desc = open(testfile,O_RDWR | O_CREAT,0666);
	if(!file_desc){
		fprintf(stderr,"unable to open %s",testfile);
		exit(1);
	} 
	
	for(start_byte =0 ;start_byte<99;start_byte+= SIZE_TO_TRY){
		region_to_test.l_type = F_WRLCK;
		region_to_test.l_whence = SEEK_SET;
		region_to_test.l_start = start_byte;
		region_to_test.l_len = SIZE_TO_TRY;
		region_to_test.l_pid = -1;
		
		printf("Testing F_WRLCK on region from %d to %d \n",
		start_byte,start_byte+SIZE_TO_TRY);
		
		//开始尝试枷锁
		res = fcntl(file_desc,F_GETLK,&region_to_test);
		if(res == -1){
			fprintf(stderr,"F_Getlk failed\n");
			exit(1);
		}
		
		if(region_to_test.l_pid !=-1){
			printf("Lock would failed.F_GETLK return\n");
			show_lock_info(&region_to_test);
		}
		else{
			printf("F_WRLCK lock would succeed\n");
		}
		
		//建立共享锁
		region_to_test.l_type = F_RDLCK;
		region_to_test.l_whence = SEEK_SET;
		region_to_test.l_start = start_byte;
		region_to_test.l_len = SIZE_TO_TRY;
		region_to_test.l_pid = -1;
		
		printf("Testing F_RDLCK on region from %d to %d \n",
		start_byte,start_byte+SIZE_TO_TRY);
		
		//开始加共享锁
		res = fcntl(file_desc,F_GETLK,&region_to_test);
		if(res == -1){
			fprintf(stderr,"F_Getlk failed\n");
			exit(1);
		}
		
		if(region_to_test.l_pid !=-1){
			printf("Lock would failed.F_GETLK return\n");
			show_lock_info(&region_to_test);
		}
		else{
			printf("F_RDLCKLCK lock would succeed\n");
		}
		
	}
	close(file_desc);
	exit(0);
}

void show_lock_info(struct flock* to_show){
	printf("\t l_type %d,",to_show->l_type);
	printf("\t l_whence %d,",to_show->l_whence);
	printf("\t l_start %d,",to_show->l_start);
	printf("\t l_len %d,",to_show->l_len);
	printf("\t l_pide %d\n",to_show->l_pid);
}