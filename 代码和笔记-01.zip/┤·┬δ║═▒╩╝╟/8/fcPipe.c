/*/*******************************************************************************
**                                                                            **
**                     Jiedi(China nanjing)Ltd.                               **
**	               创建：丁宋涛 夏曹俊，此代码可用作为学习参考                **
*******************************************************************************/

/*****************************FILE INFOMATION***********************************
**
** Project       : Linux程序设计从入门到实战
** Contact       : xiacaojun@qq.com
**  博客   : http://blog.csdn.net/jiedichina
**	视频课程 : 网易云课堂	http://study.163.com/u/xiacaojun		
			   腾讯课堂		https://jiedi.ke.qq.com/				
			   csdn学院		http://edu.csdn.net/lecturer/lecturer_detail?lecturer_id=961	
**             51cto学院	http://edu.51cto.com/lecturer/index/user_id-12016059.html	
** 			   老夏课堂		http://www.laoxiaketang.com 
**                 
**   Linux程序设计从入门到实战课程 课程群 ：1026542536 加入群下载代码和交流
**   微信公众号  : jiedi2007
**		头条号	 : 夏曹俊
**
*****************************************************************************
//！！！！！！！！！ Linux程序设计从入门到实战 课程  QQ群：1026542536下载代码和交流*/
#include "myWrapper.h"
struct grade{
	char sno[20];//学号
	char name[10];//姓名
	float chinese;
	float math;
	float english;
};

int main(){
	int count ;
	int fds[2];
	char buf[1024];
	pid_t pid;
	struct grade grad ={"19700101","laoxia",100,99,98};
	struct grade *p = buf;
	pipe(fds);
	pid =fork();
	if(pid ==0){
			//子进程
			close(fds[1]);//子进程不需要写 
			count = read(fds[0],buf,1024);
			printf("Read %d bytes,学号:%s,姓名:%s,语文:%f,数学:%f,英语:%f\n",count,p->sno,p->name,p->chinese,p->math,p->english);
			close(fds[0]);
			exit(0);

		
	}else{
		close(fds[0]);//父进程不需要读
		count = write(fds[1],(void*)&grad,sizeof(struct grade));
		printf("written %d bytes\n",count);
		close(fds[1]);
		exit(0);
	}
	
}
	