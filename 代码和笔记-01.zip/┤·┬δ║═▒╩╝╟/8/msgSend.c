/*/*******************************************************************************
**                                                                            **
**                     Jiedi(China nanjing)Ltd.                               **
**	               创建：丁宋涛 夏曹俊，此代码可用作为学习参考                **
*******************************************************************************/

/*****************************FILE INFOMATION***********************************
**
** Project       : Linux程序设计从入门到实战
** Contact       : xiacaojun@qq.com
**  博客   : http://blog.csdn.net/jiedichina
**	视频课程 : 网易云课堂	http://study.163.com/u/xiacaojun		
			   腾讯课堂		https://jiedi.ke.qq.com/				
			   csdn学院		http://edu.csdn.net/lecturer/lecturer_detail?lecturer_id=961	
**             51cto学院	http://edu.51cto.com/lecturer/index/user_id-12016059.html	
** 			   老夏课堂		http://www.laoxiaketang.com 
**                 
**   Linux程序设计从入门到实战课程 课程群 ：1026542536 加入群下载代码和交流
**   微信公众号  : jiedi2007
**		头条号	 : 夏曹俊
**
*****************************************************************************
//！！！！！！！！！ Linux程序设计从入门到实战 课程  QQ群：1026542536下载代码和交流*/
#include "myWrapper.h"
#include <sys/msg.h>
//通过命令行参数向消息队列发送一个消息
char mbuf[1024];
int main(int argc,char* argv[]){
	int rtn;
	int msqid;
	key_t key;
	if(argc !=3){
		printf("usage error\n");
		exit(1);
		
	}
	//
	//程序名 0x12345 "hello laoxia"
	//由于create已经创建了一个0x12345,因此我们在create的基础上进一步发消息
	sscanf(argv[1],"%x",&key);
	msqid = msgget(key,0644);
	*((long*)mbuf) = 1; //设置了一个为1的消息队列类型
	memcpy(mbuf+4,argv[2],strlen(argv[2])+1);//复制消息的正文
	rtn = msgsnd(msqid,mbuf,strlen(mbuf+4)+1,0);
	printf("the message to queue id is %d",msqid);
	return 0;
	
}