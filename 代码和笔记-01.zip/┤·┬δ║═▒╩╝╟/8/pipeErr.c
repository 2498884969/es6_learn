/*/*******************************************************************************
**                                                                            **
**                     Jiedi(China nanjing)Ltd.                               **
**	               创建：丁宋涛 夏曹俊，此代码可用作为学习参考                **
*******************************************************************************/

/*****************************FILE INFOMATION***********************************
**
** Project       : Linux程序设计从入门到实战
** Contact       : xiacaojun@qq.com
**  博客   : http://blog.csdn.net/jiedichina
**	视频课程 : 网易云课堂	http://study.163.com/u/xiacaojun		
			   腾讯课堂		https://jiedi.ke.qq.com/				
			   csdn学院		http://edu.csdn.net/lecturer/lecturer_detail?lecturer_id=961	
**             51cto学院	http://edu.51cto.com/lecturer/index/user_id-12016059.html	
** 			   老夏课堂		http://www.laoxiaketang.com 
**                 
**   Linux程序设计从入门到实战课程 课程群 ：1026542536 加入群下载代码和交流
**   微信公众号  : jiedi2007
**		头条号	 : 夏曹俊
**
*****************************************************************************
//！！！！！！！！！ Linux程序设计从入门到实战 课程  QQ群：1026542536下载代码和交流*/
#include "myWrapper.h"
int main(void){
	int pipe_fd[2];
	pid_t pid;
	char r_buf[4096];
	char w_buf[4096];
	
	int writenum;
	int rnum;
	memset(r_buf,0,sizeof(r_buf));
	pipe(pipe_fd);
	pid = fork();
	
	if(pid == 0){
		//close(pipe_fd[1]);
		while(1){
			rnum = read(pipe_fd[0],r_buf,1000);
			printf("[CHILD] readnum:%d\n",rnum);
			if(rnum == 0){
				printf("[CHILD] finished\n");
				break;
			}
		}
		close(pipe_fd[0]);
		exit(0);
	}
	else{
		if( pid>0){
			
			close(pipe_fd[0]);
			memset(w_buf,0,sizeof(w_buf));
			if((writenum = write(pipe_fd[1],w_buf,1024)) == -1){
				printf("[Parent] write pipe error\n");
			}
			else{
				printf("[Parent] write %d bytes\n",writenum);
				
			}
			sleep(15);
			printf("[Parent] will close the pipe\n");
			close(pipe_fd[1]);
			sleep(2);
			return 0;
		}
		
	}
	
}