/*/*******************************************************************************
**                                                                            **
**                     Jiedi(China nanjing)Ltd.                               **
**	               创建：丁宋涛 夏曹俊，此代码可用作为学习参考                **
*******************************************************************************/

/*****************************FILE INFOMATION***********************************
**
** Project       : Linux程序设计从入门到实战
** Contact       : xiacaojun@qq.com
**  博客   : http://blog.csdn.net/jiedichina
**	视频课程 : 网易云课堂	http://study.163.com/u/xiacaojun		
			   腾讯课堂		https://jiedi.ke.qq.com/				
			   csdn学院		http://edu.csdn.net/lecturer/lecturer_detail?lecturer_id=961	
**             51cto学院	http://edu.51cto.com/lecturer/index/user_id-12016059.html	
** 			   老夏课堂		http://www.laoxiaketang.com 
**                 
**   Linux程序设计从入门到实战课程 课程群 ：1026542536 加入群下载代码和交流
**   微信公众号  : jiedi2007
**		头条号	 : 夏曹俊
**
*****************************************************************************
//！！！！！！！！！ Linux程序设计从入门到实战 课程  QQ群：1026542536下载代码和交流*/
#include "myWrapper.h"
int main(void){
	int count,pid;
	int fds[2];
	const char some_data[]="0123456789";
	char buffer[1024];
	memset(buffer,'\0',sizeof(buffer));
	pipe(fds);
	pid =fork();
	if(pid==0){
		//子进程
		close(0);//关闭stdin
		dup(fds[0]);//把与管道读端的文件描述符复制为文件描述0，此时标注输入就是子进程的读端
		close(fds[0]);
		close(fds[1]);
		execlp("od","od","-c",(char*)0);
		exit(0);
		
	}
	else{
		close(fds[0]);//父进程不需要从管道读数据，因此，先关掉读端
		count = write(fds[1],some_data,strlen(some_data));
		close(fds[1]);
		printf("I have written %d bytes\n",count);
		exit(0);
		
	}
}