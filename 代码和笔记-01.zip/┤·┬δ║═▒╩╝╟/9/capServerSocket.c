/*/*******************************************************************************
**                                                                            **
**                     Jiedi(China nanjing)Ltd.                               **
**	               创建：丁宋涛 夏曹俊，此代码可用作为学习参考                **
*******************************************************************************/

/*****************************FILE INFOMATION***********************************
**
** Project       : Linux程序设计从入门到实战
** Contact       : xiacaojun@qq.com
**  博客   : http://blog.csdn.net/jiedichina
**	视频课程 : 网易云课堂	http://study.163.com/u/xiacaojun		
			   腾讯课堂		https://jiedi.ke.qq.com/				
			   csdn学院		http://edu.csdn.net/lecturer/lecturer_detail?lecturer_id=961	
**             51cto学院	http://edu.51cto.com/lecturer/index/user_id-12016059.html	
** 			   老夏课堂		http://www.laoxiaketang.com 
**                 
**   Linux程序设计从入门到实战课程 课程群 ：1026542536 加入群下载代码和交流
**   微信公众号  : jiedi2007
**		头条号	 : 夏曹俊
**
*****************************************************************************
//！！！！！！！！！ Linux程序设计从入门到实战 课程  QQ群：1026542536下载代码和交流*/
#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

typedef struct sockaddr SA;
int open_listen_sock(int port){
	int listenfd,optval;
	struct sockaddr_in serveraddr;
	char* msg;
	
	//创建socket
	if((listenfd=socket(AF_INET,SOCK_STREAM,0)) <0){
		msg = "server socket() error\n";
		write(STDOUT_FILENO,msg,strlen(msg));
		return -1;
	}
	
	msg = "server socket() success\n";
	write(STDOUT_FILENO,msg,strlen(msg));
	
	//配置服务器
	if(setsockopt(listenfd,SOL_SOCKET,SO_REUSEADDR,(const void*)&optval,sizeof(int))<0){
		msg = "server setsocketopt() error\n";
		write(STDOUT_FILENO,msg,strlen(msg));
		return -2;
	}
	msg = "server setsocketopt() success\n";
	write(STDOUT_FILENO,msg,strlen(msg));
	
	//绑定ip和端口
	bzero((char*)&serveraddr,sizeof(serveraddr));
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_port = htons((unsigned short)port);
	serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);//0.0.0.0

	if(bind(listenfd,(SA*)&serveraddr,sizeof(serveraddr))<0){
		msg = "server bind() error\n";
		write(STDOUT_FILENO,msg,strlen(msg));
		return -3;
	}
	msg = "server bind() success\n";
	write(STDOUT_FILENO,msg,strlen(msg));
	
	//创建listen
	if(listen(listenfd,1024)<0){
		msg = "server listen() error\n";
		write(STDOUT_FILENO,msg,strlen(msg));
		return -3;
		
	}
	msg = "server listen() success\n";
	write(STDOUT_FILENO,msg,strlen(msg));
	
	return listenfd;
	
}

int main(){
	int server_sockfd,client_sockfd;
	int server_len,client_len;
	struct sockaddr_in server_address;
	struct sockaddr_in client_address;
	
	server_sockfd =  open_listen_sock(9734);
	
	while(1){
		
		char ch;
		printf("server running....\n");
		
		//接受一个客户端
		client_len = sizeof(client_address);
		client_sockfd = accept(server_sockfd,(struct sockaddr*)&client_address,&client_len);
		
		read(client_sockfd,&ch,1);
		ch++;
		write(client_sockfd,&ch,1);
		close(client_sockfd);
	}
}