/*/*******************************************************************************
**                                                                            **
**                     Jiedi(China nanjing)Ltd.                               **
**	               创建：丁宋涛 夏曹俊，此代码可用作为学习参考                **
*******************************************************************************/

/*****************************FILE INFOMATION***********************************
**
** Project       : Linux程序设计从入门到实战
** Contact       : xiacaojun@qq.com
**  博客   : http://blog.csdn.net/jiedichina
**	视频课程 : 网易云课堂	http://study.163.com/u/xiacaojun		
			   腾讯课堂		https://jiedi.ke.qq.com/				
			   csdn学院		http://edu.csdn.net/lecturer/lecturer_detail?lecturer_id=961	
**             51cto学院	http://edu.51cto.com/lecturer/index/user_id-12016059.html	
** 			   老夏课堂		http://www.laoxiaketang.com 
**                 
**   Linux程序设计从入门到实战课程 课程群 ：1026542536 加入群下载代码和交流
**   微信公众号  : jiedi2007
**		头条号	 : 夏曹俊
**
*****************************************************************************
//！！！！！！！！！ Linux程序设计从入门到实战 课程  QQ群：1026542536下载代码和交流*/
#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <netdb.h>
typedef struct sockaddr SA;

int open_client_sock(char* hostname,int port){
	int clientfd;
	struct hostent *hp;
	struct sockaddr_in serveraddr;
	char* msg;
	
	if((clientfd=socket(AF_INET,SOCK_STREAM,0))<0){
		msg = "client socket() error\n";
		write(STDOUT_FILENO,msg,strlen(msg));
		return -1;
	}
	
	msg = "client socket() success\n";
	write(STDOUT_FILENO,msg,strlen(msg));
	
	//填写server的ip和port
	if((hp = gethostbyname(hostname)) == NULL){
		
		msg = "client gethost error\n";
		write(STDOUT_FILENO,msg,strlen(msg));
		return -2;
	}
	
	msg = "client gethost success\n";
	write(STDOUT_FILENO,msg,strlen(msg));

	bzero((char*)&serveraddr,sizeof(serveraddr));
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_port = htons(port);
	bcopy((char*)hp->h_addr_list[0],(char*)&serveraddr.sin_addr.s_addr,hp->h_length);
	
	//建立连接
	if(connect(clientfd,(SA*)&serveraddr,sizeof(serveraddr))<0){
		msg = "client connect error\n";
		write(STDOUT_FILENO,msg,strlen(msg));
		return -3;
	}
	
	msg = "client connect() success\n";
    write(STDOUT_FILENO,msg,strlen(msg));
	
	return clientfd;
	
}

int main(void){
	int sockfd;
	int len;
	struct sockaddr_in address;
	int result;
	char ch = 'A';
	
	sockfd = open_client_sock("localhost",9734);
	write(sockfd,&ch,1);
	read(sockfd,&ch,1);
	printf("char from Capserver is %c\n",ch);
	close(sockfd);
	exit(0);
}

