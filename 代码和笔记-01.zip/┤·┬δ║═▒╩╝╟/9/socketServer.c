/*/*******************************************************************************
**                                                                            **
**                     Jiedi(China nanjing)Ltd.                               **
**	               创建：丁宋涛 夏曹俊，此代码可用作为学习参考                **
*******************************************************************************/

/*****************************FILE INFOMATION***********************************
**
** Project       : Linux程序设计从入门到实战
** Contact       : xiacaojun@qq.com
**  博客   : http://blog.csdn.net/jiedichina
**	视频课程 : 网易云课堂	http://study.163.com/u/xiacaojun		
			   腾讯课堂		https://jiedi.ke.qq.com/				
			   csdn学院		http://edu.csdn.net/lecturer/lecturer_detail?lecturer_id=961	
**             51cto学院	http://edu.51cto.com/lecturer/index/user_id-12016059.html	
** 			   老夏课堂		http://www.laoxiaketang.com 
**                 
**   Linux程序设计从入门到实战课程 课程群 ：1026542536 加入群下载代码和交流
**   微信公众号  : jiedi2007
**		头条号	 : 夏曹俊
**
*****************************************************************************
//！！！！！！！！！ Linux程序设计从入门到实战 课程  QQ群：1026542536下载代码和交流*/
#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/un.h>
#include <unistd.h>
//本机通信的实例
// 不要在观念中认为socket就是网络通信
// 进程间通信高度上来看socket，分布式环境，多台机器协同工作的问题，
//抽象成进程间协同。
int main(){
	int a,b,c;
	int server_sock;
	int server_len;
	
	int client_sock,client_len;
	struct sockaddr_un client_address;
	
	unlink("server_socket");
	server_sock = socket(AF_UNIX,SOCK_STREAM,0);
	
	//为套接字命名
	struct sockaddr_un server_address;
	server_address.sun_family = AF_UNIX;
	strcpy(server_address.sun_path,"server_socket");
	server_len = sizeof(server_address);
	
	bind(server_sock,(struct sockaddr *)&server_address,server_len);
	
	//监听客户机的信息
	listen(server_sock,5);
	
	while(1){
		printf("server waiting...\n");
		client_len = sizeof(client_address);
		client_sock = accept(server_sock,(struct sockaddr*)&client_address,&client_len);
		read(client_sock,&a,sizeof(int));
		read(client_sock,&b,sizeof(int));
		c = a + b;
		write(client_sock,&c,sizeof(int));
		close(client_sock);
		
	}
	
	
}