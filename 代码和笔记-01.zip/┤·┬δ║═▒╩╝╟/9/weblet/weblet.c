/*/*******************************************************************************
**                                                                            **
**                     Jiedi(China nanjing)Ltd.                               **
**	               创建：丁宋涛 夏曹俊，此代码可用作为学习参考                **
*******************************************************************************/

/*****************************FILE INFOMATION***********************************
**
** Project       : Linux程序设计从入门到实战
** Contact       : xiacaojun@qq.com
**  博客   : http://blog.csdn.net/jiedichina
**	视频课程 : 网易云课堂	http://study.163.com/u/xiacaojun		
			   腾讯课堂		https://jiedi.ke.qq.com/				
			   csdn学院		http://edu.csdn.net/lecturer/lecturer_detail?lecturer_id=961	
**             51cto学院	http://edu.51cto.com/lecturer/index/user_id-12016059.html	
** 			   老夏课堂		http://www.laoxiaketang.com 
**                 
**   Linux程序设计从入门到实战课程 课程群 ：1026542536 加入群下载代码和交流
**   微信公众号  : jiedi2007
**		头条号	 : 夏曹俊
**
*****************************************************************************
//！！！！！！！！！ Linux程序设计从入门到实战 课程  QQ群：1026542536下载代码和交流*/
#include "wrapper.h"

void process_trans(int fd);
void read_requesthdrs(rio_t *rp);
int is_static(char *uri);
void parse_static_uri(char *uri,char* filename);
void parse_dynamic_uri(char *uri,char* filename,char *cgiargs);
void feed_static(int fd,char* filename,int filesize);
void get_filetype(char* filename,char* filetype);
void feed_dynamic(int fd,char* filename,char* cgiargs);
void error_request(int fd,char* cause,char* errnum,char* shortmsg,char* des);

int main(int argc,char* argv[]){
	int listen_sock,conn_sock,port,clientlen;
	struct sockaddr_in clientaddr;
	if(argc!=2){
		fprintf(stderr,"useage:<port>\n");
		exit(1);
	}
	port = atoi(argv[1]);
	
	listen_sock = open_listen_sock(port);
	while(1){
		clientlen = sizeof(clientaddr);
		conn_sock = accept(listen_sock,(SA*)&clientaddr,&clientlen);
		process_trans(conn_sock);
		close(conn_sock);
	}
	
}

int is_static(char *uri){
	if(!strstr(uri,"cgi-bin"))
		return 1;
	else
		return 0;
}

void process_trans(int fd){
	int static_flag;
	struct stat sbuf;
	char buf[MAXLINE],method[MAXLINE],uri[MAXLINE],version[MAXLINE];
	char filename[MAXLINE],cgiargs[MAXLINE];
	rio_t rio;
	
	rio_readinitb(&rio,fd);//fd就是文件描述符，我就像读文件一样的读远程
	rio_readlineb(&rio,buf,MAXLINE);
	sscanf(buf,"%s %s %s",method,uri,version);
	if(strcasecmp(method,"GET")){
		error_request(fd,method,"501","Not implemented","weblet donot implemt");
		return ;
	}
	
	read_requesthdrs(&rio);
	
	static_flag = is_static(uri);
	
	if(static_flag)
		parse_static_uri(uri,filename);
	else
		parse_dynamic_uri(uri,filename,cgiargs);
	
	
	if(stat(filename,&sbuf)<0){
		error_request(fd,filename,"404","Not found","web let dont found file");
		return ;
	}
	
	if(static_flag){
		if(!(S_ISREG(sbuf.st_mode)) || !(S_IRUSR & sbuf.st_mode)){
			error_request(fd,filename,"403","Forbidden","weblet dont have privliget");
			return;
		}
		feed_static(fd,filename,sbuf.st_size);
	}
	else{
		if(!(S_ISREG(sbuf.st_mode)) || !(S_IRUSR & sbuf.st_mode)){
			error_request(fd,filename,"403","Forbidden","weblet dont have privliget");
			return;
		}
		feed_dynamic(fd,filename,cgiargs);
	}
	
}

void error_request(int fd,char* cause,char* errnum,char* shortmsg,char* des){
	char buf[MAXLINE],body[MAXBUF];
	
	sprintf(body,"<html><title>error request</title>");
	sprintf(body,"%s<body>\r\n",body);
	sprintf(body,"%s%s:%s\r\n",body,errnum,shortmsg);
	sprintf(body,"%s<p>%s:%s\r\n",body,des,cause);
	
	//发送
	sprintf(buf,"HTTP/1.0 %s %s \r\n",errnum,shortmsg);
	rio_writen(fd,buf,strlen(buf));
	sprintf(buf,"Content-type:text/html\r\n");
	rio_writen(fd,buf,strlen(buf));
	sprintf(buf,"Content-length:%d\r\n\r\n",(int)strlen(body));
	rio_writen(fd,buf,strlen(buf));
	rio_writen(fd,body,strlen(body));
}

void read_requesthdrs(rio_t *rp){
	char buf[MAXLINE];
	
	rio_readlineb(rp,buf,MAXLINE);
	while(strcmp(buf,"\r\n")){
		printf("%s",buf);
		rio_readlineb(rp,buf,MAXLINE);
	}
}

void parse_static_uri(char *uri,char* filename){
	char *ptr;
	strcpy(filename,".");
	strcat(filename,uri);
	if(uri[strlen(uri)-1] == '/')
		strcat(filename,"home.html");
	
}
void parse_dynamic_uri(char *uri,char* filename,char *cgiargs){
	char *ptr;
	ptr = index(uri,'?');
	if(ptr){
		strcpy(cgiargs,ptr+1);
		*ptr='\0';
	}
	else
		strcpy(cgiargs,"");
	strcpy(filename,".");
	strcat(filename,uri);
}

void get_filetype(char* filename,char* filetype){
	if(strstr(filename,".html"))
		strcpy(filetype,"text/html");
}
void feed_static(int fd,char* filename,int filesize){
	int srcfd;
	char *srcp,filetype[MAXLINE],buf[MAXBUF];
	
	get_filetype(filename,filetype);
	sprintf(buf,"HTTP/1.0 200 OK \r\n");
	sprintf(buf,"%sServer:weblet Web Server\r\n",buf);
	sprintf(buf,"%sContent-length:%d\r\n",buf,filesize);
	sprintf(buf,"%sContent-type:%s \r\n\r\n",buf,filetype);
	rio_writen(fd,buf,strlen(buf));
	
	srcfd = open(filename,O_RDONLY,0);
	srcp = mmap(0,filesize,PROT_READ,MAP_PRIVATE,srcfd,0);
	close(srcfd);
	rio_writen(fd,srcp,filesize);
	munmap(srcp,filesize);
}
void feed_dynamic(int fd,char* filename,char* cgiargs){
	char buf[MAXLINE],*emptylist[] = {NULL};
	int pfd[2];
	
	sprintf(buf,"HTTP/1.0 200 OK \r\n");
	rio_writen(fd,buf,strlen(buf));
	sprintf(buf,"Server: weblet Server \r\n");
	rio_writen(fd,buf,strlen(buf));
	
	pipe(pfd);
	if( fork() ==0){
		close(pfd[1]);
		dup2(pfd[0],STDIN_FILENO);
		dup2(fd,STDOUT_FILENO);
		execve(filename,emptylist,environ);
	}
	
	close(pfd[0]);
	write(pfd[1],cgiargs,strlen(cgiargs)+1);
	wait(NULL);
	close(pfd[1]);
}