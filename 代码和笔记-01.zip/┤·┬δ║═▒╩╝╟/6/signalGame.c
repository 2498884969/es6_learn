/*/*******************************************************************************
**                                                                            **
**                     Jiedi(China nanjing)Ltd.                               **
**	               创建：丁宋涛 夏曹俊，此代码可用作为学习参考                **
*******************************************************************************/

/*****************************FILE INFOMATION***********************************
**
** Project       : Linux程序设计从入门到实战
** Contact       : xiacaojun@qq.com
**  博客   : http://blog.csdn.net/jiedichina
**	视频课程 : 网易云课堂	http://study.163.com/u/xiacaojun		
			   腾讯课堂		https://jiedi.ke.qq.com/				
			   csdn学院		http://edu.csdn.net/lecturer/lecturer_detail?lecturer_id=961	
**             51cto学院	http://edu.51cto.com/lecturer/index/user_id-12016059.html	
** 			   老夏课堂		http://www.laoxiaketang.com 
**                 
**   Linux程序设计从入门到实战课程 课程群 ：1026542536 加入群下载代码和交流
**   微信公众号  : jiedi2007
**		头条号	 : 夏曹俊
**
*****************************************************************************
//！！！！！！！！！ Linux程序设计从入门到实战 课程  QQ群：1026542536下载代码和交流*/
//我们希望通过信号机制，程序可以接受我们的键盘输入，来改变文字运动状态
#include <stdio.h>
#include <stdlib.h>
#include <curses.h>
#include <signal.h>
#include <sys/time.h>
#include <unistd.h>
#include <string.h>
#define MESSAGE "hello"
#define BLANK	"     "

int row;
int col;
int dir;

//键盘输入响应的回调函数
void move_msg(int signum);
int set_ticker(int n_msecs);

int main(void){
	//delay控制运动速度
	int delay,ndelay;
	int c;
	initscr(); //开始初始化curses库
	crmode();
	noecho();
	clear();
	row = 10;
	col = 0;
	dir = 1;//表示方向，初始时 从左向右
	delay = 200; //0.2 second
	move(row,col);
	addstr(MESSAGE);
	//注册信号响应句柄
	signal(SIGALRM,move_msg);
	set_ticker(delay);
	while(1){
		ndelay = 0;
		c = getch();
		if (c=='Q') break;
		if(c==' ') dir = -dir;
		if(c == 'f' && delay > 2) ndelay = delay /2;
		if(c == 's' ) ndelay = delay *2;
		if(ndelay > 0)
			set_ticker(delay = ndelay);
	}
	endwin();
	return 0;
}

void move_msg(int signum){
	signal(SIGALRM,move_msg);
	move(row,col);
	addstr(BLANK);
	col += dir;
	move(row,col);
	addstr(MESSAGE);
	refresh();
	if(dir == -1 && col <=0)
		dir = 1;
	else
		if(dir == 1 && col+strlen(MESSAGE) >=COLS)
		dir = -1;
}

int set_ticker(int n_msecs){
	struct itimerval new_timeset;
	long n_sec,n_usecs;
	
	n_sec = n_msecs/1000;
	n_usecs = (n_msecs%1000) * 1000L;
	
	new_timeset.it_interval.tv_sec = n_sec;	//重置一下计数
	new_timeset.it_interval.tv_usec = n_usecs;//新的计数值赋给
	new_timeset.it_value.tv_sec = n_sec;	//重置一下计数
	new_timeset.it_value.tv_usec = n_usecs;
	
	return setitimer(ITIMER_REAL,&new_timeset,NULL);
}