/*/*******************************************************************************
**                                                                            **
**                     Jiedi(China nanjing)Ltd.                               **
**	               创建：丁宋涛 夏曹俊，此代码可用作为学习参考                **
*******************************************************************************/

/*****************************FILE INFOMATION***********************************
**
** Project       : Linux程序设计从入门到实战
** Contact       : xiacaojun@qq.com
**  博客   : http://blog.csdn.net/jiedichina
**	视频课程 : 网易云课堂	http://study.163.com/u/xiacaojun		
			   腾讯课堂		https://jiedi.ke.qq.com/				
			   csdn学院		http://edu.csdn.net/lecturer/lecturer_detail?lecturer_id=961	
**             51cto学院	http://edu.51cto.com/lecturer/index/user_id-12016059.html	
** 			   老夏课堂		http://www.laoxiaketang.com 
**                 
**   Linux程序设计从入门到实战课程 课程群 ：1026542536 加入群下载代码和交流
**   微信公众号  : jiedi2007
**		头条号	 : 夏曹俊
**
*****************************************************************************
//！！！！！！！！！ Linux程序设计从入门到实战 课程  QQ群：1026542536下载代码和交流*/
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>

void handler(int sig){
	if( sig == SIGINT){
		printf("recv signo =%d\n",sig);
	}
	else{
		sigset_t uset;
		sigemptyset(&uset);
		sigaddset(&uset,SIGINT);
		//我用ctrl+\接触sigint的阻塞行为
		sigprocmask(SIG_UNBLOCK,&uset,NULL);//
		
	
	}
}

void printsigset(sigset_t *set){
	int i = 0;
	for(i=1;i<NSIG;i++){
		if(sigismember(set,i))
			putchar('1');
		else
			putchar('0');
	}
	printf("\n");
	
}

int main(void){
	sigset_t pset;//打印信号集
	sigset_t bset;//设置阻塞信号集
	
	sigemptyset(&bset);
	sigaddset(&bset,SIGINT);
	
	signal(SIGINT,handler);
	signal(SIGQUIT,handler);
	
	//一旦我按下ctrl+c，也不会打印
	sigprocmask(SIG_BLOCK,&bset,NULL);
	for(;;){
		//获取pending状态
		sigpending(&pset);
		printsigset(&pset);
		sleep(1);
		
	}
		return 0;
}
