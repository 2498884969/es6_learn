/*/*******************************************************************************
**                                                                            **
**                     Jiedi(China nanjing)Ltd.                               **
**	               创建：丁宋涛 夏曹俊，此代码可用作为学习参考                **
*******************************************************************************/

/*****************************FILE INFOMATION***********************************
**
** Project       : Linux程序设计从入门到实战
** Contact       : xiacaojun@qq.com
**  博客   : http://blog.csdn.net/jiedichina
**	视频课程 : 网易云课堂	http://study.163.com/u/xiacaojun		
			   腾讯课堂		https://jiedi.ke.qq.com/				
			   csdn学院		http://edu.csdn.net/lecturer/lecturer_detail?lecturer_id=961	
**             51cto学院	http://edu.51cto.com/lecturer/index/user_id-12016059.html	
** 			   老夏课堂		http://www.laoxiaketang.com 
**                 
**   Linux程序设计从入门到实战课程 课程群 ：1026542536 加入群下载代码和交流
**   微信公众号  : jiedi2007
**		头条号	 : 夏曹俊
**
*****************************************************************************
//！！！！！！！！！ Linux程序设计从入门到实战 课程  QQ群：1026542536下载代码和交流*/
//sysv:signal
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <errno.h>
#include <sys/syscall.h>

#define MSG_BEGIN	"I caught SIGINT"
#define MSG_END		"I finished SIGINT handler"


//模拟handler的工作
void  doWork(){
	int i,k;
	srand(time(NULL));
	for(i=0;i<1024*1024;i++)
		k = rand()%1234567;
}

void handler(int signo){
	write(2,MSG_BEGIN,strlen(MSG_BEGIN));
	doWork();
	write(2,MSG_END,strlen(MSG_END));
}

int main(void){
	char input[1024];
	//测试一下sysv风格的信号，安装是一次性的
	//sysv_signal(SIGINT,handler);
	//这个信号是可以重入的
	signal(SIGINT,handler);
	printf("input a test msg\n");
	if(fgets(input,sizeof(input),stdin) == NULL){
		fprintf(stderr,"fgets failed(%s)\n",strerror(errno));
		return -2;
	}
	else{
		printf("you entered the string is:%s",input);
	}
	return 0;
	
	
}
