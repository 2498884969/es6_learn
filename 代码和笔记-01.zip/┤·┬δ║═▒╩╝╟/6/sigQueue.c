/*/*******************************************************************************
**                                                                            **
**                     Jiedi(China nanjing)Ltd.                               **
**	               创建：丁宋涛 夏曹俊，此代码可用作为学习参考                **
*******************************************************************************/

/*****************************FILE INFOMATION***********************************
**
** Project       : Linux程序设计从入门到实战
** Contact       : xiacaojun@qq.com
**  博客   : http://blog.csdn.net/jiedichina
**	视频课程 : 网易云课堂	http://study.163.com/u/xiacaojun		
			   腾讯课堂		https://jiedi.ke.qq.com/				
			   csdn学院		http://edu.csdn.net/lecturer/lecturer_detail?lecturer_id=961	
**             51cto学院	http://edu.51cto.com/lecturer/index/user_id-12016059.html	
** 			   老夏课堂		http://www.laoxiaketang.com 
**                 
**   Linux程序设计从入门到实战课程 课程群 ：1026542536 加入群下载代码和交流
**   微信公众号  : jiedi2007
**		头条号	 : 夏曹俊
**
*****************************************************************************
//！！！！！！！！！ Linux程序设计从入门到实战 课程  QQ群：1026542536下载代码和交流*/
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>

#define MAXBUF 1024
void handler(int sig){
	pid_t pid;
	if((pid = waitpid(-1,NULL,0)) < 0){
		perror("waitpid error");
		
	}
	printf("handler cleaned child %d\n",(int)pid);
	sleep(2);
	return ;
}

int main(void){
	int i,n;
	char buf[MAXBUF];
	
	signal(SIGCHLD,handler);
	for(i=0;i<3;i++){
		if(fork() ==0 ){
			printf("from child %d\n",(int) getpid());
			sleep(1);
			exit(0);
		}
		
		
	}
	if((n=read(STDIN_FILENO,buf,sizeof(buf)))<0){
		perror("read");
	}
	printf("parent process is running\n");
	while(1){
		
	}
	
	return 0;
}