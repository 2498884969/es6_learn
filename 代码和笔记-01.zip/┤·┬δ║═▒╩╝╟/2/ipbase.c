/*/*******************************************************************************
**                                                                            **
**                     Jiedi(China nanjing)Ltd.                               **
**	               创建：丁宋涛 夏曹俊，此代码可用作为学习参考                **
*******************************************************************************/

/*****************************FILE INFOMATION***********************************
**
** Project       : Linux程序设计从入门到实战
** Contact       : xiacaojun@qq.com
**  博客   : http://blog.csdn.net/jiedichina
**	视频课程 : 网易云课堂	http://study.163.com/u/xiacaojun		
			   腾讯课堂		https://jiedi.ke.qq.com/				
			   csdn学院		http://edu.csdn.net/lecturer/lecturer_detail?lecturer_id=961	
**             51cto学院	http://edu.51cto.com/lecturer/index/user_id-12016059.html	
** 			   老夏课堂		http://www.laoxiaketang.com 
**                 
**   Linux程序设计从入门到实战课程 课程群 ：1026542536 加入群下载代码和交流
**   微信公众号  : jiedi2007
**		头条号	 : 夏曹俊
**
*****************************************************************************
//！！！！！！！！！ Linux程序设计从入门到实战 课程  QQ群：1026542536下载代码和交流*/
#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>

#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <signal.h>

//地址转化
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

int main1(void){
	unsigned int data = 0x12345678;
	char*p = (char*)&data;
	printf("%x,%x,%x,%x",p[0],p[1],p[2],p[3]);
	if(p[0] == 0x78){
		printf("小端模式");
	}
	return 0;
}

int main(void){
	in_addr_t  myIntAddr = inet_addr("192.168.1.22");
	printf("%u\n",myIntAddr);
	
	struct in_addr myAddr;
	inet_aton("192.168.1.22",&myAddr);
	printf("%u\n",myAddr.s_addr);
	printf("%s\n",inet_ntoa(myAddr));
	return 0;
}