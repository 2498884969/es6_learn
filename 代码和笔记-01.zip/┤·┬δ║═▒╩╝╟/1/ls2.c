/*/*******************************************************************************
**                                                                            **
**                     Jiedi(China nanjing)Ltd.                               **
**	               创建：丁宋涛 夏曹俊，此代码可用作为学习参考                **
*******************************************************************************/

/*****************************FILE INFOMATION***********************************
**
** Project       : Linux程序设计从入门到实战
** Contact       : xiacaojun@qq.com
**  博客   : http://blog.csdn.net/jiedichina
**	视频课程 : 网易云课堂	http://study.163.com/u/xiacaojun		
			   腾讯课堂		https://jiedi.ke.qq.com/				
			   csdn学院		http://edu.csdn.net/lecturer/lecturer_detail?lecturer_id=961	
**             51cto学院	http://edu.51cto.com/lecturer/index/user_id-12016059.html	
** 			   老夏课堂		http://www.laoxiaketang.com 
**                 
**   Linux程序设计从入门到实战课程 课程群 ：1026542536 加入群下载代码和交流
**   微信公众号  : jiedi2007
**		头条号	 : 夏曹俊
**
*****************************************************************************
//！！！！！！！！！ Linux程序设计从入门到实战 课程  QQ群：1026542536下载代码和交流*/
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <time.h>

//在linux中文件有所谓atime，mtime，ctime的概念
//现在问题是由于Linux是unix 时间戳的变体，02/26/79，05/10/77
//系统编程的套路，我们始终依靠操作系统的api来帮助我能实现功能
void printTime(time_t t){
	char timef[100];
	struct tm day;
	day = *localtime(&t);
	strftime(timef,100,"%Y-%m-%d %H:%M:%S",&day);
	printf("%s \n",timef);
}

void show_stat_info(char *fName,struct stat* buf);
int main(int ac, char* av[]){
	struct stat info; // 用来接收由linux操作系统返回给我们的条目信息
		if(ac>1)
		{
			if(stat(av[1],&info) != -1){
				show_stat_info(av[1],&info);//自己设计的用来展示的函数
				return 0;
			}
		}
		else
			perror(av[1]);
		return 1;
}
void show_stat_info(char *fName,struct stat* buf){
	printf("  mode:%o\n",buf->st_mode);
	printf("  links:%d\n",buf->st_nlink);
	printf("  user:%d\n",buf->st_uid);
	printf("  group:%d\n",buf->st_gid);
	printf("  size:%d\n",buf->st_size);
	//printf("  modetime:%d\n",buf->st_mtime);
	printTime(buf->st_mtime);
	printf("   name:%s\n",fName);
}