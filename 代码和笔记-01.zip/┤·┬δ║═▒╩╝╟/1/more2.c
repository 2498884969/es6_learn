/*/*******************************************************************************
**                                                                            **
**                     Jiedi(China nanjing)Ltd.                               **
**	               创建：丁宋涛 夏曹俊，此代码可用作为学习参考                **
*******************************************************************************/

/*****************************FILE INFOMATION***********************************
**
** Project       : Linux程序设计从入门到实战
** Contact       : xiacaojun@qq.com
**  博客   : http://blog.csdn.net/jiedichina
**	视频课程 : 网易云课堂	http://study.163.com/u/xiacaojun		
			   腾讯课堂		https://jiedi.ke.qq.com/				
			   csdn学院		http://edu.csdn.net/lecturer/lecturer_detail?lecturer_id=961	
**             51cto学院	http://edu.51cto.com/lecturer/index/user_id-12016059.html	
** 			   老夏课堂		http://www.laoxiaketang.com 
**                 
**   Linux程序设计从入门到实战课程 课程群 ：1026542536 加入群下载代码和交流
**   微信公众号  : jiedi2007
**		头条号	 : 夏曹俊
**
*****************************************************************************
//！！！！！！！！！ Linux程序设计从入门到实战 课程  QQ群：1026542536下载代码和交流*/
#include <stdio.h>
#include <stdlib.h>
#define PAGELEN 24
#define LINELEN 512
void do_more(FILE* fp);//这个是用来接收一个文件，将其显示
int see_more(FILE *fp);//这个在显示中，用来接收用户和程序之间交互按键：enter，space
int main(int ac,char *av[]){
	FILE *fp;
	if(ac == 1){
		do_more(stdin);//标准C程序在调用中发现，我们仅仅使用了more命令
		//那么他的处理对象就直接定位到标准输入。
		
	}
	else{
		while(--ac)
			if((fp =fopen(*++av,"r")) !=NULL){
				do_more(fp);
				fclose(fp);
			}
			else{
				exit(1);//你输入的所有的参数都不能当作文件名
				//传输给当前的程序，那么，就报非正常终止
			}
	}
	return 0;
}
void do_more(FILE* fp){
	char line[LINELEN];//我们用char数组作为缓冲区
	int num_of_lines =0;//我们对每一屏显示的行数进行计数
	//只要不满24行，且文件还有内容，就要交互
	int reply ;//用来接收用户和程序之间交互按键：enter，space的返回值
	//设定dev/tty和当前程序的标准输入、输出的关系
	FILE *fp_tty;
	fp_tty = fopen("/dev/tty","r");
	if(fp_tty == NULL)
		exit(1);
	
	while(fgets(line,LINELEN,fp)){
		if(num_of_lines == PAGELEN){
			//当前已经一屏幕满了，那么就要开始交互
			reply = see_more(fp_tty);
			if(reply == 0)
				break;
			num_of_lines -= reply;//reply实际上返回的是下一次
			//需要显示的行数,如果说我们输入的是空格
			//那么我们就将下次显示的长度设为24行
			//输入的是回车，则显示的是再显示一行
		
		}
		if(fputs(line,stdout)== EOF)
			exit(1);
		num_of_lines++;
		
		
	}
	
}

//seemore是满24行的时候，我们进行交互的辅助函数
int see_more(FILE* cmd){
	int c;
	printf("\033[7m more?\033[m"); //vt100 终端，反白的显示要求
	//while((c=getchar()) !=EOF){
	while((c=getc(cmd)) !=EOF){//将我们的接受读入的形式，从tty获得
		if( c== 'q')
			return 0;
		if(c == ' ')
			return PAGELEN;
		if(c == '\n')
			return 1;
	}
	return 0;
}