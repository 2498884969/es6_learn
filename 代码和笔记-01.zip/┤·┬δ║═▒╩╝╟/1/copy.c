/*/*******************************************************************************
**                                                                            **
**                     Jiedi(China nanjing)Ltd.                               **
**	               创建：丁宋涛 夏曹俊，此代码可用作为学习参考                **
*******************************************************************************/

/*****************************FILE INFOMATION***********************************
**
** Project       : Linux程序设计从入门到实战
** Contact       : xiacaojun@qq.com
**  博客   : http://blog.csdn.net/jiedichina
**	视频课程 : 网易云课堂	http://study.163.com/u/xiacaojun		
			   腾讯课堂		https://jiedi.ke.qq.com/				
			   csdn学院		http://edu.csdn.net/lecturer/lecturer_detail?lecturer_id=961	
**             51cto学院	http://edu.51cto.com/lecturer/index/user_id-12016059.html	
** 			   老夏课堂		http://www.laoxiaketang.com 
**                 
**   Linux程序设计从入门到实战课程 课程群 ：1026542536 加入群下载代码和交流
**   微信公众号  : jiedi2007
**		头条号	 : 夏曹俊
**
*****************************************************************************
//！！！！！！！！！ Linux程序设计从入门到实战 课程  QQ群：1026542536下载代码和交流*/
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>

//定义文件的
#define COPYMODE 0644
#define BUFFERSIZE 4094

//如果在使用的时候，自己拷贝自己可以吗?
//比如磁盘满了,inode
void oops(char *s1,char *s2){
	fprintf(stderr,"Error:%s",s1);
	perror(s2);
	exit(1);
}


int main(int ac,char* argv[]){
	int in_fd,out_fd,n_chars;
	char buf[BUFFERSIZE];
	//cp srcfile destfile
	if(ac!=3){
		fprintf(stderr,"usage error");
		exit(1);
	}
	
	if((in_fd=open(argv[1],O_RDONLY)) == -1){
		oops("Cannot open",argv[1]);
	}
	
	if((out_fd=creat(argv[2],COPYMODE)) == -1){
		oops("Cannot create",argv[2]);
	}
	
	while((n_chars = read(in_fd,buf,BUFFERSIZE))>0){
		if(write(out_fd,buf,n_chars) != n_chars)
			oops("Write error",argv[2]);
	}
	
	if(close(in_fd) == -1 || close(out_fd) == -1)
		oops("error closing files","");
}