/*/*******************************************************************************
**                                                                            **
**                     Jiedi(China nanjing)Ltd.                               **
**	               创建：丁宋涛 夏曹俊，此代码可用作为学习参考                **
*******************************************************************************/

/*****************************FILE INFOMATION***********************************
**
** Project       : Linux程序设计从入门到实战
** Contact       : xiacaojun@qq.com
**  博客   : http://blog.csdn.net/jiedichina
**	视频课程 : 网易云课堂	http://study.163.com/u/xiacaojun		
			   腾讯课堂		https://jiedi.ke.qq.com/				
			   csdn学院		http://edu.csdn.net/lecturer/lecturer_detail?lecturer_id=961	
**             51cto学院	http://edu.51cto.com/lecturer/index/user_id-12016059.html	
** 			   老夏课堂		http://www.laoxiaketang.com 
**                 
**   Linux程序设计从入门到实战课程 课程群 ：1026542536 加入群下载代码和交流
**   微信公众号  : jiedi2007
**		头条号	 : 夏曹俊
**
*****************************************************************************
//！！！！！！！！！ Linux程序设计从入门到实战 课程  QQ群：1026542536下载代码和交流*/
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <utmp.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

void show_info(struct utmp * utbuffp){
	struct tm *pMytime;
	if(strstr(utbuffp->ut_line,"pts")){
	printf("% -8.8s",utbuffp->ut_name);
	printf(" ");
	//修正bydingst,比较一下，希望仅仅显示pts0虚拟终端的内容
	
	printf("% -8.8s",utbuffp->ut_line);
	printf(" ");
	//修正by dingst，将时间转化成human形式
	pMytime = gmtime(&utbuffp->ut_time);
	printf("%d年%d月%d日:%2d:%2d:%2d",pMytime->tm_year,
	pMytime->tm_mon+1,
	pMytime->tm_mday,
	pMytime->tm_hour,
	pMytime->tm_min,
	pMytime->tm_sec);
	//printf("% -8.8d",utbuffp->ut_time);
	//修正by dingst：每一条记录换行
	printf("\n");
	}
}
int main(void){
	struct utmp current_record;//这个就是将要读取的分量
	int utmpfd;//utmp的文件描述符
	int recordLength = sizeof(current_record);
	
	if ((utmpfd = open(UTMP_FILE,O_RDONLY)) == -1){
		perror(UTMP_FILE);
		exit(1);
	}
	
	while(read(utmpfd,&current_record,recordLength) == recordLength){
		show_info(&current_record);
	}
	
	close(utmpfd);
	return 0;
}